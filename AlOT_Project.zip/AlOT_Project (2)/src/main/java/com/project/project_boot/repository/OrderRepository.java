package com.project.project_boot.repository;

public interface OrderRepository {
}
