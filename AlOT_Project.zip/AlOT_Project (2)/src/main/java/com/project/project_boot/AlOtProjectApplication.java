package com.project.project_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlOtProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlOtProjectApplication.class, args);
	}

}
