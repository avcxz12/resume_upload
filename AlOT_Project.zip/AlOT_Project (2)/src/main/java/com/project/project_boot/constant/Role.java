package com.project.project_boot.constant;


public enum Role {

	
	
    ADMIN, MANAGER, USER;


}