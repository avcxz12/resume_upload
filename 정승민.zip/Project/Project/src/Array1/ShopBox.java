package Array1;

public class ShopBox {
	public void Box1(){
	String BoxNam = "샷건";
	int GetS=0;
	GetS++;
	int Get=0;
	Get++;
	}
	public void Box2() {
	String BoxNam = "소총";
	int GetG=0;
	GetG++;
	int Get=0;
	Get++;
	}
	public void Box3() {
	String BoxNam = "칼";
	int GetK=0;
	GetK++;
	int Get=0;
	Get++;
	}

}
