package Array1;

public class Bank_info {
	public int Don() {
		int Money=0;
		return Money;
	}

}
